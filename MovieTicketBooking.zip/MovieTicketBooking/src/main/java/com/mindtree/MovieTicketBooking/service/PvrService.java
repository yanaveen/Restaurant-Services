package com.mindtree.MovieTicketBooking.service;

import java.util.List;
import java.util.Optional;

import com.mindtree.MovieTicketBooking.entity.PVR;

public interface PvrService {
	
	PVR savepvr(PVR pvr);
	List<PVR> saveAllpvr(List<PVR> pvr);
	List<PVR> getAllpvrs();
	PVR getpvrById(long id);
	void deletepvr(long id);
	PVR updatepvr(PVR pvr,long id);

}
