package com.mindtree.MovieTicketBooking.service;

import java.util.List;
import java.util.Optional;

import com.mindtree.MovieTicketBooking.DTO.MovieTicketDTO;
import com.mindtree.MovieTicketBooking.entity.Screen;
import com.mindtree.MovieTicketBooking.entity.User;

public interface UserService {

	User saveuser(User user);
	void saveAllUsers(List<User> user);
	List<User> getusers();
	User getuserById(long id);
	void deleteUser(long id);
	User updateuser(User user,long id);
	User getuserByName(String name);

  
	

}
