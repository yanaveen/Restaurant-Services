package com.mindtree.MovieTicketBooking.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.MovieTicketBooking.entity.Inox;
import com.mindtree.MovieTicketBooking.exception.ResourseNotFoundException;
import com.mindtree.MovieTicketBooking.repository.InoxRepository;
import com.mindtree.MovieTicketBooking.service.InoxService;


@Service
@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class InoxServiceImpl implements InoxService {
	//constructor type dependency as been injected to InoxRepository
	private InoxRepository inoxRepo;

	public InoxServiceImpl(InoxRepository inoxRepo) {
		super();
		this.inoxRepo = inoxRepo;
	}

	@Override
	public Inox saveinox(Inox inox) {
		// TODO Auto-generated method stub
	
		return inoxRepo.save(inox);
	}

	@Override
	public void saveAll(List<Inox> inox) {
		// TODO Auto-generated method stub
		 inoxRepo.saveAll(inox);
	}

	@Override
	public List<Inox> getAllInox() {
		// TODO Auto-generated method stub
		return inoxRepo.findAll();
	}

	@Override
	public void deleteInox(long id) {
		// TODO Auto-generated method stub
		inoxRepo.findById(id).orElseThrow(() -> 
		                            new ResourseNotFoundException("Inox", "Id", id));
		inoxRepo.deleteById(id);
	}

	@Override
	public Inox updateInox(Inox inox, long id) {
		// TODO Auto-generated method stub
		//we need to check wheather inox with given id exists in DB or Not
		Inox existingInox = inoxRepo.findById(id).orElseThrow(() -> 
		                             new ResourseNotFoundException("Inox", "id", id));
		existingInox.setId(inox.getId());
		existingInox.setScreen(inox.getScreen());
		//save existing user to DB
		inoxRepo.save(existingInox);
		return existingInox;
	}

	@Override
	public Inox getInox(long id) {
		/*
		 * //Exception using if else Optional<Inox> user = inoxRepo.findById(id);
		 * if(user.isPresent()) { return user.get(); }else { throw new
		 * ResourseNotFoundException("Inox", "Id",id); }
		 */
		//Exception using Lambda 
		  inoxRepo.findById(id).orElseThrow(() -> new
		                     ResourseNotFoundException("Inox", "Id", id));
		  return inoxRepo.getById(id);
	}
}
