package com.mindtree.MovieTicketBooking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.MovieTicketBooking.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	/*
	 * User findByEmailId(String email);
	 */
//	  User findById(int i);
      User getUserByName(String name);
      
	 
}
