package com.mindtree.MovieTicketBooking.entity;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Movie implements Comparable<Movie> {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String title;
	private String releaseDate;
	private String showcycle;

	/*
	 * @OneToOne(cascade = CascadeType.ALL) private Screen screen;
	 */
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	/*
	 * public Screen getScreen() { return screen; } public void setScreen(Screen
	 * screen) { this.screen = screen; }
	 */
	
	public String getShowcycle() {
		return showcycle;
	}
	public void setShowcycle(String showcycle) {
		this.showcycle = showcycle;
	}
	
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Movie(long id, String title, String releaseDate, String showcycle) {
		super();
		this.id = id;
		this.title = title;
		this.releaseDate = releaseDate;
		this.showcycle = showcycle;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, releaseDate, showcycle, title);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		return id == other.id && Objects.equals(releaseDate, other.releaseDate)
				&& Objects.equals(showcycle, other.showcycle) && Objects.equals(title, other.title);
	}
	@Override
	public String toString() {
		return "Movie [id=" + id + ", title=" + title + ", releaseDate=" + releaseDate + ", showcycle=" + showcycle
				+ "]";
	}
	@Override
	public int compareTo(Movie o) {
		// TODO Auto-generated method stub
		return this.title.compareTo(o.title);
	}
	
	

}
