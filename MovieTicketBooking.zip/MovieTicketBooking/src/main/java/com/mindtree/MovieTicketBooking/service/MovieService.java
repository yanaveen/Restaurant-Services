package com.mindtree.MovieTicketBooking.service;

import java.util.List;
import java.util.Optional;

import com.mindtree.MovieTicketBooking.entity.Movie;

public interface MovieService {
	Movie savemovie(Movie movie);
	List<Movie> saveallmovie(List<Movie> movie);
	List<Movie> getallmovies();
	Movie getmoviebyid(long id);
	void deletemovie(long id);
	Movie updatemovie(Movie movie,long id);

}
