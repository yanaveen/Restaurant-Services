package com.mindtree.MovieTicketBooking.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.MovieTicketBooking.entity.PVR;
import com.mindtree.MovieTicketBooking.exception.ResourseNotFoundException;
import com.mindtree.MovieTicketBooking.repository.PvrRepository;
import com.mindtree.MovieTicketBooking.service.PvrService;



@Service
@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.SUPPORTS, readOnly = false, timeout = 30)
public class PvrServiceImpl implements PvrService {
	@Autowired
	private PvrRepository pvrRepo;

	/*
	 * //constructor type dependecy as been injected to pvrServiceimpl class public
	 * PvrServiceImpl(PvrRepository pvrRepo) { super(); this.pvrRepo = pvrRepo; }
	 */
	@Override
	public PVR savepvr(PVR pvr) {
		// TODO Auto-generated method stub
		
		return pvrRepo.save(pvr);
		
	}
	@Override
	public List<PVR> saveAllpvr(List<PVR> pvr) {
		// TODO Auto-generated method stub
	   return pvrRepo.saveAll(pvr);
		
	}
	@Override
	public List<PVR> getAllpvrs() {
		// TODO Auto-generated method stub
		return pvrRepo.findAll();
	}
	@Override
	public void deletepvr(long id) {
		// TODO Auto-generated method stub
		  pvrRepo.findById(id).orElseThrow(() -> 
		                  new ResourseNotFoundException("PVR", "Id", id));
		  pvrRepo.deleteById(id);
		
	}
	@Override
	public PVR updatepvr(PVR pvr, long id) {
		// TODO Auto-generated method stub
		PVR existingPvr = pvrRepo.findById(id).orElseThrow(() -> 
		 new ResourseNotFoundException("PVR", "Id", id));
		existingPvr.setId(pvr.getId());
		existingPvr.setScreen(pvr.getScreen());
		//save existing pvr to DB
		pvrRepo.save(existingPvr);
		return existingPvr;
	}
	@Override
	public PVR getpvrById(long id) {
		return  pvrRepo.findById(id).orElseThrow(() -> 
		                    new ResourseNotFoundException("PVR", "Id", id));
	
	}
	

}
