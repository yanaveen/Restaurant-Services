package com.mindtree.MovieTicketBooking.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.mindtree.MovieTicketBooking.entity.User;
import com.mindtree.MovieTicketBooking.exception.ResourseNotFoundException;
import com.mindtree.MovieTicketBooking.repository.UserRepository;
import com.mindtree.MovieTicketBooking.service.UserService;



@Service
@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED, readOnly = false, timeout = 30)
public class UserServiceImpl implements UserService {
	//constructor type dependency as been injected to UserServiceImpl class 
	@Autowired
	private UserRepository userRepo;
	
	

	@Override
	public User saveuser(User user) {
		return userRepo.save(user);
	}

	@Override
	public void saveAllUsers(List<User> user) {
		// TODO Auto-generated method stub
		userRepo.saveAll(user);
	}

	@Override
	public List<User> getusers() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}

	@Override
	public User getuserById(long id) {
		// TODO Auto-generated method stub
		//Exception using if else
				/*
				 * Optional<User> user = userRepo.findById(id); if(user.isPresent()) { return
				 * user.get(); }else { throw new ResourseNotFoundException("User", "Id",id); }
				 */
				
				//Using lambda expressions
				return userRepo.findById(id).orElseThrow(() ->
				new ResourseNotFoundException("User", "Id", id));
			}

	@Override
	public void deleteUser(long id) {
		//check wheather a user exist in DB or not
		userRepo.findById(id).orElseThrow(() -> 
		                      new ResourseNotFoundException("User", "Id", id));
		userRepo.deleteById(id);
	}

	@Override
	public User updateuser(User user, long id) {
		
		//we need to check wheather user with given id exist in DB or not
		User existingUser = userRepo.findById(id).orElseThrow(()
				-> new ResourseNotFoundException("User", "Id", id));
		existingUser.setName(user.getName());
		existingUser.setPwd(user.getPwd());
		//save existing user to DB
		userRepo.save(existingUser);
		return existingUser;
	}

	@Override
	public User getuserByName(String name) {
		//return userRepo.
		 return userRepo.getUserByName(name);
	}

}
