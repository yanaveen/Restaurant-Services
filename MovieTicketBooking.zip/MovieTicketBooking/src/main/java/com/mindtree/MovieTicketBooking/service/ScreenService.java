package com.mindtree.MovieTicketBooking.service;

import java.util.List;
import java.util.Optional;
import com.mindtree.MovieTicketBooking.entity.Screen;

public interface ScreenService {
	
	Screen savescreen(Screen screen);
	List<Screen> saveallscreen(List<Screen> screen);
	List<Screen> getallscreens();
	Screen getscreenById(long id);
	void deletescreen(long id);
	Screen updatescreen(Screen screen,long id);

}
