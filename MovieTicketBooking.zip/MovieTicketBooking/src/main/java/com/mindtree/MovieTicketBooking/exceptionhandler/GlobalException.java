package com.mindtree.MovieTicketBooking.exceptionhandler;

public class GlobalException {

}
