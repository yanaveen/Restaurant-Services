package com.mindtree.MovieTicketBooking.entity;

public interface CinemaIf {

}
