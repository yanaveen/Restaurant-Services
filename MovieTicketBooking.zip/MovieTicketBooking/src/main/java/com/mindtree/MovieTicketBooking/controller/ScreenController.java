package com.mindtree.MovieTicketBooking.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.MovieTicketBooking.entity.Inox;
import com.mindtree.MovieTicketBooking.entity.Screen;
import com.mindtree.MovieTicketBooking.service.InoxService;
import com.mindtree.MovieTicketBooking.service.ScreenService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@EnableTransactionManagement
@RequestMapping("/screen")
public class ScreenController {
	@Autowired
	private ScreenService screenservice;
	
	private static final Logger logger = LoggerFactory.getLogger(ScreenController.class);
	
	//build screen Rest Api
	//http://localhost:8080/screen/addscreen
	@PostMapping("/addscreen")
	public ResponseEntity<Screen> savescreen(@RequestBody Screen screen) {
		Screen savedscreen=screenservice.savescreen(screen);
		logger.debug("Successfully created");
		return new ResponseEntity<Screen>( savedscreen, HttpStatus.CREATED);
	}
	
	//build All screens Rest Api
	//http://localhost:8080/screen/addscreens
	@PostMapping("/addscreens")
	public void savescreens(@RequestBody List<Screen> screen) {
		 screenservice.saveallscreen(screen); 
		logger.debug("Successfully Created");
	}
	//build get screen by using id
	//http://localhost:8080/screen/{id}
	@GetMapping("/{id}")
	public ResponseEntity<Screen> getscreen(@PathVariable("id") long Id){
		//fetch the data using id
		Screen screen = screenservice.getscreenById(Id);
		if(screen==null) {
			logger.error("No data with this Id");
			return new ResponseEntity<Screen>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Screen>(screen,HttpStatus.OK);
	}
	//buid get all screen by using Rest api
	//http://localhost:8080/screen/allscreens
	@GetMapping("/allscreens")
	public List<Screen> getallscreens(){
		//save multiple data into DB
		logger.debug("Details Fetched");
		return screenservice.getallscreens();
	}
	//build update screen Rest Api
	//http://localhost:8080/screen/updatescreen
	@PutMapping("/{id}")
	public ResponseEntity<Screen> updatescreen(@PathVariable long Id,@RequestBody Screen screen) {
		//Update the Screen using id
		Screen updatescreen = screenservice.updatescreen(screen, Id);
		if(updatescreen==null) {
			logger.error("Error In Screen");
			return new ResponseEntity<Screen>(HttpStatus.NOT_FOUND);
		}
		logger.debug("Screen Updated");
		return new ResponseEntity<Screen>(updatescreen,HttpStatus.OK);
		
	}
	//build delete screen using id Rest Api
	//http://localhost:8080/screen/{id}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deletescreen(@PathVariable("id") long id) {
		//Delete Screen data from DB
		screenservice.deletescreen(id);
		logger.debug("Successfully deleted");
		return new ResponseEntity<String>("Screen data deleted successfully",HttpStatus.OK);
	}

}
