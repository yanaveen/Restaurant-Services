package com.mindtree.MovieTicketBooking.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.MovieTicketBooking.entity.User;
import com.mindtree.MovieTicketBooking.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class LoginController {
	@Autowired
	private UserService userservice;
	
	//build a login Rest Api
	//http://localhost:8080/login
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	//build an login Rest Api to post the data in login form
	//http://localhost:8080/login
	@PostMapping("/login")
	public String welcome(Model model,@RequestParam String name, @RequestParam String pwd) {
		User user=userservice.getuserByName(name);
		if(user.getPwd().equals(pwd)) {
			model.addAttribute("name",name);
			return "welcome";
		}
		model.addAttribute("ermsg", "please provide corect user credential");
		return "login";
	}
	//build an signup rest api to get the data
	//http://localhost:8080/signin
	@GetMapping("/signin")
	public String signup() {
		return "signin";
	}
	//build an signup RestApi to post the data
	//http://localhost:8080/signin
	@PostMapping("/signin")
	public String signup(Model model,@RequestParam String name,@RequestParam String pwd) {
		User user=new User();
		user.setName(name);
		user.setPwd(pwd);
		userservice.saveuser(user);
		model.addAttribute("name", name);
		return "welcome";
	}
	

}
