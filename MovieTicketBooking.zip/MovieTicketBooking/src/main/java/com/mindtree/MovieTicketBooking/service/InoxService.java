package com.mindtree.MovieTicketBooking.service;

import java.util.List;
import java.util.Optional;

import com.mindtree.MovieTicketBooking.entity.Inox;

public interface InoxService {
	
	Inox saveinox(Inox inox);
	void saveAll(List<Inox> inox);
	List<Inox> getAllInox();
	Inox getInox(long id);
	void deleteInox(long id);
	Inox updateInox(Inox inox,long id);

}
