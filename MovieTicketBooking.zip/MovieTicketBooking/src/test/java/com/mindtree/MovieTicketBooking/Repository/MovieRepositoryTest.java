package com.mindtree.MovieTicketBooking.Repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.mindtree.MovieTicketBooking.entity.Movie;
import com.mindtree.MovieTicketBooking.repository.MovieRepository;

@DataJpaTest
public class MovieRepositoryTest {
//	@Autowired
//	private MovieRepository movieRepository;
//	
//	@Test
//	public void testsaveMovie() {
//		Movie movie = new Movie();
//			movie.setTitle("ABC");
//			movie.setReleaseDate("12-2-2022");
//			movie.setShowcycle("12AM");
//			movieRepository.save(movie);
//			assertNotNull(movie);
//		
//	}

}
